package MyPackage;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class OutPut {
    static File outPutFile = new File("output.txt");
    static FileWriter outPut;

    static {
        try {
            outPut = new FileWriter(outPutFile);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    static public void print(String string) {
        try {
            outPut.write(string + "\n");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    static public void close() {
        try {
            outPut.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
