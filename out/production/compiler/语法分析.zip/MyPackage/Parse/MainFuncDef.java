package MyPackage.Parse;

public class MainFuncDef implements Decl{
    private Block block;

    public MainFuncDef(Block block) {
        this.block = block;
    }
}
