package MyPackage.Parse;

import java.util.ArrayList;

public class MulExp {
    private ArrayList<UnaryExp> unaryExps;
    private ArrayList<String> op;

    public MulExp(ArrayList<UnaryExp> unaryExps, ArrayList<String> op) {
        this.unaryExps = unaryExps;
        this.op = op;
    }
}
