package MyPackage.Parse;

import java.util.ArrayList;

public class Stmt {
    private int type;
    private LVal lVal;
    private ArrayList<Exp> exps;
    private Block block;
    private Cond cond;
    private Stmt stmt1;
    private Stmt stmt2;
    private ForStmt forStmt1;
    private ForStmt forStmt2;
    private String formatString;

    public Stmt(LVal lVal, Exp exp) {
        type = 0;
        this.lVal = lVal;
        exps = new ArrayList<>();
        exps.add(exp);
    }

    public Stmt(Exp exp) {
        type = 1;
        exps = new ArrayList<>();
        exps.add(exp);
    }

    public Stmt(Block block) {
        type = 2;
        this.block = block;
    }

    public Stmt(Cond cond, Stmt stmt) {
        type = 3;
        this.cond = cond;
        this.stmt1 = stmt;
    }

    public Stmt(Cond cond, Stmt stmt1, Stmt stmt2) {
        type = 4;
        this.cond = cond;
        this.stmt1 = stmt1;
        this.stmt2 = stmt2;
    }

    public Stmt(ForStmt forStmt1, Cond cond, ForStmt forStmt2, Stmt stmt) {
        type = 5;
        this.stmt1 = stmt;
        this.forStmt1 = forStmt1;
        this.forStmt2 = forStmt2;
        this.cond = cond;
    }

    public Stmt(int type) {
        this.type = type;
    } // 6 break; 7 continue;

    public Stmt(int type, Exp exp) {
        this.type = 8;
        assert type == 8;
        exps = new ArrayList<>();
        exps.add(exp);
    }

    public Stmt(LVal lVal) {
        type = 9;
        this.lVal = lVal;
    }

    public Stmt(String formatString, ArrayList<Exp> exps) {
        type = 10;
        this.formatString = formatString;
        this.exps = exps;
    }
}
