package MyPackage.Parse;

import java.util.ArrayList;

public class LVal {
    private String ident;
    private ArrayList<Exp> exps;

    public LVal(String ident, ArrayList<Exp> exps) {
        this.ident = ident;
        this.exps = exps;
    }

    public String getIdent() {
        return ident;
    }
}
