package MyPackage.Parse;


public class PrimaryExp {
    private int type;
    private Exp exp;
    private LVal lVal;
    private int number;

    public PrimaryExp(Exp exp) {
        type = 0;
        this.exp = exp;
    }

    public PrimaryExp(LVal lVal) {
        type = 1;
        this.lVal = lVal;
    }

    public PrimaryExp(int number) {
        type = 2;
        this.number = number;
    }
}
