package MyPackage.Parse;

import java.util.ArrayList;

public class FuncFParam {
    private String type;
    private String ident;
    private ArrayList<ConstExp> constExps;

    public FuncFParam(String type, String ident, ArrayList<ConstExp> constExps) {
        this.type = type;
        this.ident = ident;
        this.constExps = constExps;
    }


}
