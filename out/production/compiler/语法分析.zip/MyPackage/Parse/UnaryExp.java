package MyPackage.Parse;


public class UnaryExp {
    private int type;
    private PrimaryExp primaryExp;
    private String ident;
    private FuncRParams funcRParams;
    private UnaryOp unaryOp;
    private UnaryExp unaryExp;

    public UnaryExp(PrimaryExp primaryExp) {
        type = 0;
        this.primaryExp = primaryExp;
    }

    public UnaryExp(String ident, FuncRParams funcRParams) {
        type = 1;
        this.ident = ident;
        this.funcRParams = funcRParams;
    }

    public UnaryExp(UnaryOp unaryOp, UnaryExp unaryExp) {
        type = 2;
        this.unaryOp = unaryOp;
        this.unaryExp = unaryExp;
    }


}
