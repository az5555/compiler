package MyPackage.Parse;

import java.util.ArrayList;

public class EqExp {
    private ArrayList<RelExp> relExps;
    private ArrayList<String> op;
    public EqExp(ArrayList<RelExp> relExps, ArrayList<String> op) {
        this.relExps = relExps;
        this.op = op;;
    }
}
