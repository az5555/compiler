import MyPackage.Laxer;
import MyPackage.OutPut;

import java.io.File;

public class Compiler {
    public static void main(String[] args) {
        File file = new File("testfile.txt");
        Laxer laxer = new Laxer(file);
        OutPut outPut = new OutPut(laxer);
        try {
            outPut.print();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}