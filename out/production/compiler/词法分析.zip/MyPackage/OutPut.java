package MyPackage;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class OutPut {
    Laxer laxer;
    File outPutFile;
    FileWriter outPut;
    public OutPut(Laxer laxer) {
        this.laxer = laxer;
        outPutFile = new File("output.txt");
        try {
            outPut = new FileWriter(outPutFile);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void print() throws Exception {
        while (!laxer.isEnd()) {
            laxer.nextToken();
            if (laxer.getToken().equals("")) {
                continue;
            }
            outPut.write(laxer.getLexType() + " " + laxer.getToken() + "\n");
        }
        try {
            outPut.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
