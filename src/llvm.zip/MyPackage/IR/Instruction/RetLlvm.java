package MyPackage.IR.Instruction;

import MyPackage.IR.Type;
import MyPackage.IR.User;
import MyPackage.OutPut;


public class RetLlvm extends User {
    public RetLlvm(Type type, int value) {
        super(type, value);
    }

    @Override
    public void print() {
        if (getType().equals(Type.Void)) {
            OutPut.printLlvm("    ret void\n");
        }
        else {
            OutPut.printLlvm(String.format("    ret %s %s\n", super.printType(), getOperands().get(0).printValue()));
        }
    }
}
