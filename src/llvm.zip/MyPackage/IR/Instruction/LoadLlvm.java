package MyPackage.IR.Instruction;

import MyPackage.IR.ArrayLlvm;
import MyPackage.IR.Type;
import MyPackage.IR.User;
import MyPackage.OutPut;
import MyPackage.Symbol.MyValSymbol;
import MyPackage.Symbol.Symbol;

public class LoadLlvm extends User {
    MyValSymbol symbol;
    ArrayLlvm arrayLlvm;
    public LoadLlvm(Type type, int value, Symbol symbol) {
        super(type, value);
        this.symbol = (MyValSymbol) symbol;
    }


    @Override
    public void print() {
        OutPut.printLlvm(String.format("    %s = load %s, %s * ", super.printValue(), getOperands().get(1).printType(),
                    getOperands().get(1).printType()));
         if (symbol.isGlobal() && getOperands().get(1) == symbol.getReg()) {
            OutPut.printLlvm(String.format("@%s\n", symbol.getName()));
        }
        else {
            OutPut.printLlvm(String.format("%s\n", getOperands().get(1).printValue()));
        }
    }

    public void setArrayLlvm(ArrayLlvm arrayLlvm) {
        this.arrayLlvm = arrayLlvm;
    }

    @Override
    public String printType() {
        if (getType().equals(Type.Array)) {
            return arrayLlvm.printType();
        }
        else {
            return super.printType();
        }
    }
}
