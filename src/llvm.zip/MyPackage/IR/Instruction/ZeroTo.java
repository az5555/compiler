package MyPackage.IR.Instruction;

import MyPackage.IR.Type;
import MyPackage.IR.User;
import MyPackage.OutPut;

public class ZeroTo extends User {
    public ZeroTo(Type type, int value) {
        super(type, value);
    }

    public void print() {
        OutPut.printLlvm(String.format("    %s = zext %s %s to %s\n", super.printValue(),
                getOperands().get(0).printType(), getOperands().get(0).printValue(), super.printType()));
    }
}
