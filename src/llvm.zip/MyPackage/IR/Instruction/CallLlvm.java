package MyPackage.IR.Instruction;

import MyPackage.IR.Type;
import MyPackage.IR.User;
import MyPackage.IR.Value;
import MyPackage.OutPut;
import MyPackage.Symbol.FunSymbol;

public class CallLlvm extends User {
    String funSymbol;
    public CallLlvm(Type type, int value, String funSymbol) {
        super(type, value);
        this.funSymbol = funSymbol;
    }

    @Override
    public void print() {
        if (!getType().equals(Type.Void)) {
            OutPut.printLlvm(String.format("    %s = ", super.printValue()));
        }
        else {
            OutPut.printLlvm("    ");
        }
        OutPut.printLlvm(String.format("call %s @%s(", super.printType(), funSymbol));
        for (int i = 0; i < getOperands().size(); i++) {
            Value value = getOperands().get(i);
            if (i != getOperands().size() - 1) {
                OutPut.printLlvm(String.format("%s %s, ", value.printType(), value.printValue()));
            }
            else {
                OutPut.printLlvm(String.format("%s %s)\n", value.printType(), value.printValue()));
            }
        }
        if (getOperands().size() == 0) {
            OutPut.printLlvm(")\n");
        }
    }


}
