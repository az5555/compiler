package MyPackage.IR.Instruction;

import MyPackage.IR.Type;
import MyPackage.IR.User;
import MyPackage.OutPut;

public class IcmpLlvm extends User {
    String cond;
    public IcmpLlvm(Type type, int value, String cond) {
        super(type, value);
        this.cond = cond;
    }

    @Override
    public void print() {
        OutPut.printLlvm(String.format("    %s = icmp %s %s %s, %s\n", super.printValue(), cond, getOperands().get(0).printType(),
                getOperands().get(0).printValue(), getOperands().get(1).printValue()));
    }
}
