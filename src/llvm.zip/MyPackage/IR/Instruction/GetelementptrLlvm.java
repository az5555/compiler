package MyPackage.IR.Instruction;

import MyPackage.IR.ArrayLlvm;
import MyPackage.IR.DeclLlvm;
import MyPackage.IR.Type;
import MyPackage.IR.User;
import MyPackage.OutPut;
import MyPackage.Symbol.MyValSymbol;

import java.util.ArrayList;

public class GetelementptrLlvm extends User {
    MyValSymbol symbol;

    public GetelementptrLlvm(Type type, int value, MyValSymbol symbol) {
        super(type, value);
        this.symbol = symbol;
    }

    @Override
    public void print() {
        OutPut.printLlvm(String.format("    %s = getelementptr %s ,%s* "
                , super.printValue(), getOperands().get(0).printType(), getOperands().get(0).printType()));
        if (symbol.isGlobal()) {
            OutPut.printLlvm(String.format("@%s", symbol.getName()));
        }
        else {
            OutPut.printLlvm(String.format("%s", getOperands().get(0).printValue()));
        }
        for (int i = 1; i < getOperands().size(); i++) {
            OutPut.printLlvm(String.format(", %s %s", getOperands().get(i).printType(), getOperands().get(i).printValue()));
        }
        OutPut.printLlvm("\n");
    }

    @Override
    public String printType() {
        if (!getType().equals(Type.Array)) {
            return super.printType();
        }
        else {
            int dim;
            if (symbol.isGlobal()) {
                dim = ((DeclLlvm) symbol.getReg()).getDim().get(1);
            }
            else {
                dim = ((AllocaLlvm)symbol.getReg()).getArrayLlvm().getDim().get(((AllocaLlvm)symbol.getReg()).getArrayLlvm().getDim().size() - 1);
            }
            return String.format("[%d x i32]*", dim);
        }
    }
}
