package MyPackage.IR.Instruction;

import MyPackage.IR.Type;
import MyPackage.IR.User;
import MyPackage.OutPut;
import MyPackage.Symbol.MyValSymbol;

public class StoreLlvm extends User {
    private MyValSymbol symbol;
    public StoreLlvm(Type type, int value, MyValSymbol symbol) {
        super(type, value);
        this.symbol = symbol;
    }

    @Override
    public void print() {
        OutPut.printLlvm(String.format("    store %s %s, %s * ", getOperands().get(0).printType(), getOperands().get(0).printValue(),
                    getOperands().get(0).printType()));
        if (symbol.isGlobal() && getOperands().get(1) == symbol.getReg()) {
            OutPut.printLlvm(String.format("@%s\n", symbol.getName()));
        }
        else {
            OutPut.printLlvm(String.format("%s\n", getOperands().get(1).printValue()));
        }
    }
}
