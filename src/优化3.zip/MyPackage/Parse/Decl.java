package MyPackage.Parse;

import MyPackage.IR.Value;

public interface Decl {
     public void generateLlvm(boolean isGlobal);
}
