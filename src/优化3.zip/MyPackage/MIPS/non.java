package MyPackage.MIPS;

public class non implements Mips{
    @Override
    public void print() {

    }

    public non() {

    }
}
