package MyPackage.MIPS;

public interface Mips {

    public void print();
}
