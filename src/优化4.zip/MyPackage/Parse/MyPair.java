package MyPackage.Parse;

public class MyPair {
    public int first;
    public boolean second;

    public MyPair(int first, boolean second) {
        this.first = first;
        this.second = second;
    }

}
