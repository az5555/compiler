package MyPackage.Parse;


import MyPackage.Parser;
import MyPackage.Symbol.FunSymbol;
import MyPackage.Symbol.Symbol;
import MyPackage.Symbol.SymbolTable;

public class UnaryExp {
    private int type;
    private PrimaryExp primaryExp;
    private String ident;
    private FuncRParams funcRParams;
    private UnaryOp unaryOp;
    private UnaryExp unaryExp;

    public UnaryExp(PrimaryExp primaryExp) {
        type = 0;
        this.primaryExp = primaryExp;
    }

    public UnaryExp(String ident, FuncRParams funcRParams) {
        type = 1;
        this.ident = ident;
        this.funcRParams = funcRParams;
    }

    public UnaryExp(UnaryOp unaryOp, UnaryExp unaryExp) {
        type = 2;
        this.unaryOp = unaryOp;
        this.unaryExp = unaryExp;
    }

    public int getLevel() {
        if (type == 1) {
            Symbol symbol = Parser.getRoot().search(ident);
            if (symbol instanceof FunSymbol) {
                if (symbol.getType().equals("void")) {
                    return -1;
                }
                else {
                    return 0;
                }
            }
        }
        if (type != 0) {
            return 0;
        }
        return primaryExp.getLevel();
    }
}
