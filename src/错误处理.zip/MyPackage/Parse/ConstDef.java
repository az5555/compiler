package MyPackage.Parse;

import java.util.ArrayList;

public class ConstDef {
    private String ident;
    private ArrayList<ConstExp> constExps;
    private ConstInitVal constInitVal;

    public ConstDef(ArrayList<ConstExp> constExps, ConstInitVal constInitVal, String ident) {
        this.constExps = constExps;
        this.constInitVal = constInitVal;
        this.ident = ident;
    }

}
