package MyPackage.Parse;

public class FuncDef implements Decl{
    private String type;
    private String ident;
    private FuncFParams funcFParams;
    private Block block;

    public FuncDef(String type, String ident, FuncFParams funcFParams, Block block) {
        this.type = type;
        this.funcFParams = funcFParams;
        this.block = block;
        this.ident = ident;
    }
}
