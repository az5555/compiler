package MyPackage.Parse;

import java.util.ArrayList;

public class FuncFParam {
    private String type;
    private String ident;
    private ArrayList<ConstExp> constExps;
    private int level;

    public FuncFParam(String type, String ident, ArrayList<ConstExp> constExps,int level) {
        this.type = type;
        this.ident = ident;
        this.constExps = constExps;
        this.level = level;
    }

    public int getLevel() {
        return level;
    }
}
