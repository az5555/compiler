package MyPackage.Parse;

import java.util.ArrayList;

public class InitVal {
    private Exp exp;
    private int type;
    private ArrayList<InitVal> initValS;

    public InitVal(Exp exp) {
        this.exp = exp;
        type = 0;
    }

    public InitVal(ArrayList<InitVal> initValS) {
        this.initValS = initValS;
        type = 1;
    }
}
