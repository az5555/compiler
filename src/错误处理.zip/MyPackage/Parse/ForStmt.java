package MyPackage.Parse;

public class ForStmt {
    private LVal lVal;
    private Exp exp;

    public ForStmt(LVal lVal, Exp exp) {
        this.lVal = lVal;
        this.exp = exp;
    }
}
