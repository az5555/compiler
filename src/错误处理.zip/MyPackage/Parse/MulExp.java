package MyPackage.Parse;

import java.util.ArrayList;

public class MulExp {
    private ArrayList<UnaryExp> unaryExps;
    private ArrayList<String> op;

    public MulExp(ArrayList<UnaryExp> unaryExps, ArrayList<String> op) {
        this.unaryExps = unaryExps;
        this.op = op;
    }

    public int getLevel() {
        if (unaryExps.size() > 1) {
            return 0;
        }
        return unaryExps.get(0).getLevel();
    }
}
