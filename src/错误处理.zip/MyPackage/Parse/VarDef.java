package MyPackage.Parse;

import java.util.ArrayList;

public class VarDef {
    private String ident;
    private ArrayList<ConstExp> constExps;
    private InitVal initVal;

    public VarDef(ArrayList<ConstExp> constExps, InitVal initVal, String ident) {
        this.constExps = constExps;
        this.initVal = initVal;
        this.ident = ident;
    }
}
