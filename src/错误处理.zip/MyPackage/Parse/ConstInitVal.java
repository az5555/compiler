package MyPackage.Parse;

import java.util.ArrayList;

public class ConstInitVal {
    private ConstExp constExp;
    private ArrayList<ConstInitVal> constInitValS;
    private int type;


    public ConstInitVal(ConstExp constExp) {
        this.constExp = constExp;
        type = 0;
    }

    public ConstInitVal(ArrayList<ConstInitVal> constInitValS) {
        this.constInitValS = constInitValS;
        type = 1;
    }
}
