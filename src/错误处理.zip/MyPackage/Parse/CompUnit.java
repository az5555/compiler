package MyPackage.Parse;


import java.util.ArrayList;

public class CompUnit {
    final private ArrayList<Decl> list;
    public CompUnit(ArrayList<Decl> list) {
        this.list = list;
    }


}
