package MyPackage.Parse;

import java.util.ArrayList;

public class RelExp {
    private ArrayList<AddExp> addExps;
    private ArrayList<String> op;

    public RelExp(ArrayList<AddExp> addExps, ArrayList<String> op) {
        this.addExps = addExps;
        this.op = op;
    }
}
