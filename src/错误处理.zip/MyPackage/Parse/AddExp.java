package MyPackage.Parse;

import java.util.ArrayList;

public class AddExp {
    private ArrayList<MulExp> mulExps;
    private ArrayList<String> op;


    public AddExp(ArrayList<MulExp> mulExps, ArrayList<String> op) {
        this.mulExps = mulExps;
        this.op = op;
    }

    public int getLevel() {
        if (mulExps.size() > 1) {
            return 0;
        }
        return mulExps.get(0).getLevel();
    }

}
