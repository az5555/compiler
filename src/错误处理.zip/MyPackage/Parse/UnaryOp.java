package MyPackage.Parse;

public class UnaryOp {
    private String op;

    public UnaryOp(String string) {
        op = string;
    }
}
