package MyPackage.Parse;

public interface Decl {
}
