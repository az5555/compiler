package MyPackage.Parse;

import MyPackage.Parser;
import MyPackage.Symbol.MyValSymbol;
import MyPackage.Symbol.Symbol;

import java.util.ArrayList;

public class LVal {
    private String ident;
    private ArrayList<Exp> exps;

    public LVal(String ident, ArrayList<Exp> exps) {
        this.ident = ident;
        this.exps = exps;
    }

    public String getIdent() {
        return ident;
    }

    public int getLevel() {
        Symbol symbol = Parser.getCurSymbolTable().search(ident);
        if (symbol instanceof MyValSymbol) {
            return ((MyValSymbol)symbol).getLevel() - exps.size();
        }
        return exps.size();
    }
}
