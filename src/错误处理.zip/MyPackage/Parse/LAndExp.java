package MyPackage.Parse;

import java.util.ArrayList;

public class LAndExp {
    private ArrayList<EqExp> eqExps;

    public LAndExp (ArrayList<EqExp> eqExps) {
        this.eqExps = eqExps;
    }

}
