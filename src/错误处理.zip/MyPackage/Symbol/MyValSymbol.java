package MyPackage.Symbol;

import java.util.ArrayList;

public class MyValSymbol extends Symbol{
    private int level;
    private ArrayList<Integer> levels;

    public MyValSymbol(String name, int line, boolean isConst, String type, int level) {
        super(name, line, isConst, type);
        this.level = level;
    }

    public int getLevel() {
        return level;
    }

    public int getLevel(int index) {
        return levels.get(index);
    }
}
